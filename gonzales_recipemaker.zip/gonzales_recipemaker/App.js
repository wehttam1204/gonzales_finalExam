import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import * as SQLite from 'expo-sqlite';

let db = null;

export const setupDatabase = async () => {
  db = await SQLite.openDatabaseAsync('recipes.db');
  await db.execAsync(
    `CREATE TABLE IF NOT EXISTS recipes (
      id INTEGER PRIMARY KEY AUTOINCREMENT, 
      title TEXT, 
      description TEXT
    );
    INSERT INTO recipes (title, description) VALUES 
      ('Adobo', '- One piece chicken\\n- Toyo\\n- Calamansi'),
      ('Spaghetti', '- Pasta\\n- Tomato Sauce\\n- Ground Beef'),
      ('Sinangag', '- Garlic\\n- Rice\\n- Oil');`
  );
};

export default function App() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [items, setItems] = useState([]);
  const [editingItem, setEditingItem] = useState(null);
  const [showMainApp, setShowMainApp] = useState(false);
  const [expandedItems, setExpandedItems] = useState({});

  useEffect(() => {
    setupDatabase().then(fetchItems);
  }, []);

  const fetchItems = async () => {
    if (!db) return;
    const results = await db.getAllAsync('SELECT id, title, description FROM recipes;');
    setItems(results.map((row) => ({ id: row.id, title: row.title, description: row.description })));
  };

  const addItem = async () => {
    if (db === null || title === '' || description === '') return;
    await db.runAsync('INSERT INTO recipes (title, description) VALUES (?, ?);', [title, description]);
    setTitle('');
    setDescription('');
    fetchItems();
  };

  const editItem = (item) => {
    setTitle(item.title);
    setDescription(item.description);
    setEditingItem(item);
  };

  const updateItem = async () => {
    if (db === null || !editingItem || title === '' || description === '') return;
    await db.runAsync('UPDATE recipes SET title = ?, description = ? WHERE id = ?;', [title, description, editingItem.id]);
    setTitle('');
    setDescription('');
    setEditingItem(null);
    fetchItems();
  };

  const deleteItem = async (id) => {
    if (db === null) return;
    await db.runAsync('DELETE FROM recipes WHERE id = ?;', [id]);
    fetchItems();
  };

  const toggleExpand = (id) => {
    setExpandedItems((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  if (!showMainApp) {
    return (
      <View style={styles.welcomeContainer}>
        <Text style={styles.welcomeTitle}>Welcome to the Recipe App!</Text>
        <Text style={styles.welcomeSubtitle}>Your kitchen companion for saving and managing recipes.</Text>
        <TouchableOpacity style={styles.startButton} onPress={() => setShowMainApp(true)}>
          <Text style={styles.startButtonText}>Get Started</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.appContainer}>
      <View style={styles.innerContainer}>
        <Text style={styles.title}>Add a Cooking Recipe</Text>
        <TextInput
          placeholder="Enter recipe title"
          value={title}
          onChangeText={setTitle}
          style={styles.input}
        />
        <TextInput
          placeholder="Enter recipe description"
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={5}
          style={styles.input}
        />
        <Button
          title={editingItem ? "Update Recipe" : "Add Recipe"}
          onPress={editingItem ? updateItem : addItem}
          color="#4682B4"
        />
        <FlatList
          style={styles.list}
          data={items}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.recipeItem}>
              <TouchableOpacity style={{ flex: 1 }} onPress={() => toggleExpand(item.id)}>
                <Text style={styles.recipeTitle}>{item.title}</Text>
                {expandedItems[item.id] && (
                  <Text style={styles.recipeDescription}>{item.description}</Text>
                )}
              </TouchableOpacity>
              <View style={styles.buttonRow}>
                <TouchableOpacity onPress={() => editItem(item)}>
                  <Text style={styles.editButton}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => deleteItem(item.id)}>
                  <Text style={styles.deleteButton}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  welcomeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fefefe',
    padding: 30,
  },
  welcomeTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#4682B4',
    textAlign: 'center',
    marginBottom: 10,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
    marginBottom: 30,
  },
  startButton: {
    backgroundColor: '#4682B4',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 10,
  },
  startButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  appContainer: {
    flex: 1,
    backgroundColor: '#f0f8ff',
  },
  innerContainer: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
    textAlignVertical: 'top',
    borderRadius: 6,
  },
  list: {
    marginTop: 20,
  },
  recipeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: '#e6f2ff',
    marginBottom: 5,
    borderRadius: 6,
  },
  recipeTitle: {
    fontWeight: 'bold',
    fontSize: 16,
    color: '#333',
  },
  recipeDescription: {
    marginTop: 5,
    whiteSpace: 'pre-wrap',
    color: '#444',
  },
  buttonRow: {
    flexDirection: 'row',
    marginLeft: 10,
    alignSelf: 'center',
  },
  editButton: {
    color: 'blue',
    marginRight: 10,
  },
  deleteButton: {
    color: 'red',
  },
});
